package com.greatoutdoor.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.greatoutdoor.entity.WishlistTb;

public interface WishListRepo extends JpaRepository<WishlistTb, Long> {

}
