package com.greatoutdoor.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.greatoutdoor.entity.Product;
import com.greatoutdoor.entity.Wishlist;
import com.greatoutdoor.entity.WishlistTb;
import com.greatoutdoor.service.WishlistService;

@RestController
@RequestMapping("/wishlist")
public class WishlistController {
	@Autowired
	public RestTemplate restTemplate;

	@Autowired
	private WishlistService wishservice;

	@PostMapping("/add")
	public Wishlist addWishlist(@RequestBody Wishlist wishlist) {
		
		WishlistTb wishListtb = new WishlistTb();
		
		List<Long> temp = new ArrayList<Long>();

		for (Product pro : wishlist.getProducts()) {
			temp.add(pro.getProductId());
		}
		wishListtb.setProductIds(temp);
		wishListtb = wishservice.addWishlist(wishListtb);

		wishlist.setWishid(wishListtb.getWishid());
		List<Product> lis=new ArrayList<Product>();
		for(Product p:wishlist.getProducts()) {
			p.setWishid(wishlist.getWishid());
			lis.add(p);
		}
		wishlist.setProducts(lis);
		return wishlist;
	}

	@GetMapping("/{wishlist}")
	public Wishlist viewwishlist(@PathVariable("wishlist") Long id) {
		
		WishlistTb wish = this.wishservice.getWishid(id);
		
		List<Product> temp=new ArrayList<Product>();
		for(Long pid:wish.getProductIds()) {
			Product prod=restTemplate.getForObject("http://localhost:2001/hero/" + pid, Product.class);
			prod.setWishid(id);
			temp.add(prod);
		}

		Wishlist wishList=new Wishlist(wish.getWishid(),temp);

		return wishList;

	}

}
