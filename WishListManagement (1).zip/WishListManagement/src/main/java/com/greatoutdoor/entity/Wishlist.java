package com.greatoutdoor.entity;

import java.util.List;



public class Wishlist {


		private Long wishid;
		private List<Product> products;

		public Long getWishid() {
			return wishid;
		}

		public void setWishid(Long wishid) {
			this.wishid = wishid;
		}



		public Wishlist(Long wishid, List<Product> products) {
			super();
			this.wishid = wishid;
			this.products = products;
		}

		public List<Product> getProducts() {
			return products;
		}

		public void setProducts(List<Product> products) {
			this.products = products;
		}

		public Wishlist() {
			super();
		}

	}

