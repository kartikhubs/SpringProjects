package com.greatoutdoor.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Wishlistdata")
public class WishlistTb {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long wishid;
	@ElementCollection
	private List<Long> productIds;

	public Long getWishid() {
		return wishid;
	}

	public void setWishid(Long wishid) {
		this.wishid = wishid;
	}


	public WishlistTb(Long wishid, List<Long> productIds) {
		super();
		this.wishid = wishid;
		this.productIds = productIds;
	}

	public List<Long> getProductIds() {
		return productIds;
	}

	public void setProductIds(List<Long> productIds) {
		this.productIds = productIds;
	}

	public WishlistTb() {
		super();
	}

}
