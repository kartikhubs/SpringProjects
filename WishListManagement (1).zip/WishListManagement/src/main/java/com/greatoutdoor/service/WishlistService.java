package com.greatoutdoor.service;

import com.greatoutdoor.entity.WishlistTb;

public interface WishlistService{

	public WishlistTb addWishlist(WishlistTb wishlist);
	
	public WishlistTb getWishid(Long wishid);
}
