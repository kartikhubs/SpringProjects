package com.greatoutdoor.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.greatoutdoor.entity.WishlistTb;
import com.greatoutdoor.repository.WishListRepo;

@Service
public class WishlistServiceimp implements WishlistService {

	@Autowired
	private WishListRepo repository;

	@Override
	public WishlistTb addWishlist(WishlistTb wishlist) {

		return repository.save(wishlist);
	}

	@Override
	public WishlistTb getWishid(Long wishid) {

		return repository.findById(wishid).get();
	}

	// static data

}
