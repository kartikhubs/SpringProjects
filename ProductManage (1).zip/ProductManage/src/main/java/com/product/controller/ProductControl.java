package com.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.product.entity.Product;
import com.product.service.ProductService;

@RestController
@RequestMapping("/hero")
public class ProductControl {

	// Dependency Injection
	@Autowired
	private ProductService productService;

	// Add a Product
	@PostMapping("/add")
	public ResponseEntity<Product> addProduct(@RequestBody Product product) {
		return new ResponseEntity<Product>(productService.addProduct(product), HttpStatus.CREATED);
	}

	// View All Products
	@GetMapping("/viewProduct")
	public List<Product> viewAllProducts() {

		return productService.viewAllProducts();
	}

	// View product by id //will be called by WISHLIST
	@GetMapping(value = "/{productId}")
	public Product viewProduct(@PathVariable("productId") Long productId) {
		return productService.viewProduct(productId);
	}

	// Update the product
	@PutMapping("/edit/{productId}")
	public Product editProduct(@RequestBody Product product, @PathVariable("productId") Long productId) {
		return productService.editProduct(product, productId);
	}

	// Delete the product
//	@DeleteMapping("/delete/{productId}")
//	public void deleteProduct(@PathVariable("productId") Long productId) {
//		productService.deleteProduct(productId);
//	}

}
