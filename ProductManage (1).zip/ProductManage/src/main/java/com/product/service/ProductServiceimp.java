package com.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.entity.Product;
import com.product.repository.ProductRepo;

@Service
public class ProductServiceimp implements ProductService {

	// Dependency Injection
	@Autowired
	private ProductRepo productRepository;

	public Product addProduct(Product product) {

		return productRepository.save(product);
	}

	public List<Product> viewAllProducts() {

		return productRepository.findAll();
	}

	public Product viewProduct(Long id) {

		return productRepository.findById(id).get();
	}

	public Product editProduct(Product product,Long productId) {

		return productRepository.save(product);
	}

}